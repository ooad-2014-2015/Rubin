﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    class DioZaAerobik
    {
        public DateTime datumRezervacije { get; set; }
        public int brojTermina { get; set; }

 /*       public static DateTime dajDatumRezervacije() { }
        public static bool provjeriVrijemeRezervacije() { }
        public static int dajBrojTermina() { }
   */
    }
}
