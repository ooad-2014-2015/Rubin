﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    public class DioZaVaterpolo:Prostor
    {
        public DateTime datumRezervacije { get; set; }

  /*      public static DateTime dajDatumRezervacije() {  }
        public static bool provjeriVrijemeRezervacije() { }
   */
    }
}
