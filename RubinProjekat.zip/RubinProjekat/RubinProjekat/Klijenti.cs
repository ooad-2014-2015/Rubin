﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    class Klijenti
    {
        static public BindingList<Klijent> klijenti = new BindingList<Klijent>();

        public static void dodajKlijenta() { }
        public static void obrisiKlijenta() { }
    }
}
