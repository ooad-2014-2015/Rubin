﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    public  class Recepcioner
    {
        public string id { get; set; }
        /*private static int dajId() { }*/
    }
}
