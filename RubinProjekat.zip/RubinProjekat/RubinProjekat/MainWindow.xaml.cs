﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RubinProjekat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrEmpty(textbox1.Text)) && !(string.IsNullOrEmpty(textbox2.Password)))
            {
                if (textbox1.Text == "admin" && textbox2.Password == "admin")
                {
                    Recepcioner r = new Recepcioner();
                    r.id = textbox1.Text;
                    Window1 pregled = new Window1();
                    pregled.ShowDialog();
                }
                else MessageBox.Show("Neispravni login podaci");
                
            }

            else MessageBox.Show("Morate unijeti i username i password!");

        }
    }
}
