﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    public class MjesecnaKarta
    {
        private double cijenaMK { get; set; }

       /* public static double dajCijenuMK() { }*/
    }
}
