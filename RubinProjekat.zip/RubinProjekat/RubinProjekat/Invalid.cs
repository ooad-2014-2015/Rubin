﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    public  class Invalid: Klijent
    {
        private bool imaPotvrduOInvaliditetu { get; set; }

     /*   public static bool dajPotvrduInvalida() {}*/
    }
}
