﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    public  class JednokratnoKoristenje
    {
        private double cijenaJK { get; set; }

      /*  public static double dajCijenuJK() { }*/
    }
}
