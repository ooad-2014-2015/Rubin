﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    class DnevnaKarta:Usluge
    {
        public double cijenaDK { get; set; }

    /*    public static double dajCijenuDK() { }*/
    }
}
