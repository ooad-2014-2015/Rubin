﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
namespace RubinProjekat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            try{
            Recepcioner.ucitajListuKNAlogaIBaze();
            
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string userName = textbox1.Text;
            string password = textbox2.Password;
            bool pronasao = false;

            if ((userName == "admin") && (password == "admin"))
            {
                    
                    Window1 prozor1 = new Window1();
                    prozor1.Show();
                    pronasao = true;
            }

            if (!pronasao)
            {
                for (int i = 0; i < Recepcioner.listaRecepcionera.Count; i++)
                {
                    if (Recepcioner.listaRecepcionera[i].username == userName && Recepcioner.listaRecepcionera[i].password == password)
                    {
                        Window1 prozor1 = new Window1();
                        prozor1.Show();
                        pronasao = true;
                    }
                }
            }

            if ((textbox1.Text == "") || (textbox2.Password == ""))
            {
                MessageBox.Show("Niste unijeli sve potrebne podatke.", "Poruka");
                textbox1.Text = "";
                textbox2.Password = "";
            }

            if (!pronasao && (textbox1.Text != "" && textbox2.Password != ""))
            {
                MessageBox.Show("Korisnicki nalog sa ovim podacima nije registrovan.", "Poruka");
                textbox1.Text = "";
                textbox2.Password = "";
            }
      

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ukoliko želite ući u aplikaciju neophodno je da unesete username admin i password admin ili neki od username-a i passworda iz baze. Nakon toga otvara vam se prozor sa opcijom jednokratno korištenje i da se učlanite. Ukoliko odaberete jednokratno korištenje unosite ime, prezime i da li želite dodatne usluge. Također postoji i opcija za evidentiranje štete i štampanje računa. Ukoliko odaberete opciju da postanete član unosite ime, prezime, adresu, datum rođenja i ima li klijent pravo na popust i postoji opcija za evidenciju štete i štampanje računa.");
        }
    }
}
