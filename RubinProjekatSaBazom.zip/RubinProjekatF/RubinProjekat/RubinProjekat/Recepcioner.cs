﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace RubinProjekat
{
    public  class Recepcioner
    {
        public string id { get; set; }
        public string username { get; set; }
        public string password { get; set; }

        public Recepcioner()
        {

        }

        public Recepcioner(string _username, string _password)
        {
            username = _username;
            password = _password;
        }

        public static List<Recepcioner> listaRecepcionera = new List<Recepcioner>();

        public static void ucitajListuKNAlogaIBaze()
        {
            string username = "root";
            string password = "";
            string db = "rubin";
            //Konekcija na bazu 
            string connectionString = "server=localhost;user=" + username + ";pwd=" + password + ";database=" + db;
            MySqlConnection con = new MySqlConnection(connectionString);
            con.Open();

            MySqlCommand upitKomanda = new MySqlCommand("select * from recepcioneri", con);
            MySqlDataReader r = upitKomanda.ExecuteReader();
            while (r.Read())
            {
                listaRecepcionera.Add(new Recepcioner(r.GetString("username"), r.GetString("password")));

            }


        }
      
    }
}
