﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    public class Klijent
    {	
        private String imePrezime { get; set; }
        private String adresa { get; set; }
        private DateTime datumRodjenja { get; set; }
        private int id { get; set; }

      /*  public Klijent() { }
        public static String dajImePrezime() { }
        public static void promijeniImePrezime() { }
        public static String dajAdresu() { }
        public static DateTime dajDatumRodjenja() { }
        public static int dajId() { }       

       */ 
    }
}
