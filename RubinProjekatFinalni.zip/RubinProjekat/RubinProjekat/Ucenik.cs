﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    public class Ucenik:Klijent
    {
        private bool imaPotvrdu { get; set; }

       /* public static bool dajPotvrduUcenika() {}*/
    }
}
