﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubinProjekat
{
    public class Student:Klijent 
    {
        public bool imaKopijuIndexa { get; set; }

      /*  public static bool dajPotvrduStudenta() { }*/
    }
}
