﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using pupcane_vrpce.Resources;
using Microsoft.Phone.Tasks;

namespace pupcane_vrpce
{
    public partial class MainPage : PhoneApplicationPage
    {
        string s;
        
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            s="Koristenje:"+"\n"+"sauna: \n" +"Bazen \n" + "fitnes \n" + "Teretana \n";
            MessageBox.Show(s);

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            s = "-Karta : 4h korištenje kompletanog kompleksa sportsko-rekreativnog centra „Rubin“ \n -Dnevna karta (podrazumjeva korištenje kompletnog kompleksa od trenutka kupovine do 22h) \n -Mjesečna karta (podrazumjeva korištenje kompletnog kompleksa 30 dana od datuma kupovine karte) \n - Polugodišnja karta (podrazumjeva korištenje kompletnog kompleksa 182 dana od datuma kupovine karte) \n -Godišnja karta (podrazumjeva korištenje kompletnog kompleksa 365 dana od datuma kupovine karte)";
            MessageBox.Show(s);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            s = "Postoje cetiri vrste popusta: \n 1.) Popust za učenike - uz priloženo uvjerenje da je klijent redovan učenik osnovne ili srednje škole on može ostvariti popust za kompletan kompleks sportsko-rekreativnog centra „Rubin“ \n 2.) Popust za studente - uz priloženu kopiju indeksa ili uvjerenja da je klijent redovan student, on može ostvariti popust za kompletan kompleks sportsko-rekreativnog centra „Rubin“ \n 3.) Popust za penzionere uz priložen ček od penzije penzioneri mogu ostvariti popust za kompletan kompleks sportsko-rekreativnog centra „Rubin“ \n 4.)Popust za invalide - uz potvrdu o invaliditetu invalidi mogu ostvariti popust za kompletan kompleks sportsko-rekreativnog centra „Rubin“";
            MessageBox.Show(s);
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ovdje se nalaze informacije o našim uslugama, paketima te mogućnostima. \n Takođe ,tu se nalazi i link koji vodi na youtube kanal koji pokazuje kako pravilno da se vježba i koristi teretana");
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            WebBrowserTask webBrowserTask = new WebBrowserTask();
            webBrowserTask.Uri = new Uri("https://www.youtube.com/watch?v=vkKCVCZe474");
            webBrowserTask.Show();
        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}