﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asoc
{
    class Kviz
    {
        private NivoTezine _nivo;
        private Asocijacije _asocijacije;

        public Kviz(bool nivo)
        {
            if (nivo == false)
            {
            }
        }
        public Asocijacije Asocijacije
        {
            get { return _asocijacije; }
            set { _asocijacije = value; }
        }
        
        public NivoTezine Nivo
        {
            get { return _nivo; }
            set { _nivo = value; }
        }

        int obracunajBodove()
        { 
        }
    }
}
