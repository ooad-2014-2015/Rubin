﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace asoc
{
    class Asocijacije
    {
        private String _konacno;
        private List<Asocijacija> kolone;

        public List<Asocijacija> Kolone
        {
            get { return kolone; }
            set { kolone = value; }
        }

        public String Konacno
        {
            get { return _konacno; }
            set { _konacno = value; }
        }

        public bool validirajKonacno(String naziv)
        { }

    }

    
}
