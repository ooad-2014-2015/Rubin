﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asoc
{
    class _4Slike1Rijec
    {
        private String _konacno;
        private List<SlikeRijec> _slike;

        public List<SlikeRijec> Slike
        {
            get { return _slike; }
            set { _slike = value; }
        }

        public String Konacno
        {
            get { return _konacno; }
            set { _konacno = value; }
        }
        public bool validirajKonacno(String naziv)
        { }
    }
}
