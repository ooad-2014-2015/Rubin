﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asoc
{
    public class Asocijacija
    {
        private List<String> _rijeci;

        public List<String> Rijeci
        {
            get { return _rijeci; }
            set { _rijeci = value; }
        }
    }
}
