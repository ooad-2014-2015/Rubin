﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asoc
{
    static class Asocijacija
    {
        static public BindingList<ListaA> asoc = new BindingList<ListaA>();
    }
}
