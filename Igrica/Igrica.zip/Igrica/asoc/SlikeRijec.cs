﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asoc
{
    class SlikeRijec
    {
        private List<String> _slike;

        public List<String> Slike
        {
            get { return _slike; }
            set { _slike = value; }
        }

    }
}
