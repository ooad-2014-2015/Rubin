﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace asoc
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static bool Expert;
        List<string> Asocij;
        int BrojBodova = 0;
        public MainWindow()
        {
            InitializeComponent();
            unospojma.Visibility = System.Windows.Visibility.Hidden;
            unospojmab.Visibility = System.Windows.Visibility.Hidden;
            unospojmac.Visibility = System.Windows.Visibility.Hidden;
            unospojmad.Visibility = System.Windows.Visibility.Hidden;
            konacno.Visibility = System.Windows.Visibility.Hidden;
            if (!Expert) hint1.Visibility = System.Windows.Visibility.Visible;
            if (!Expert) hint2.Visibility = System.Windows.Visibility.Visible;
            if (!Expert) hint3.Visibility = System.Windows.Visibility.Visible;
            if (!Expert) hint4.Visibility = System.Windows.Visibility.Visible;
            if (!Expert) hint5.Visibility = System.Windows.Visibility.Visible;
        }

        private void A1_Click(object sender, RoutedEventArgs e)
        {
            A1.Content = asoc(0);
            A1.Background = Brushes.DeepSkyBlue;
        }

        private string asoc(int ind)
        {
            List<string> Asocij;
            Asocij = new List<string> { "7 clanova", "igraci", "vodeni sport", "lopta", "vaterpolo", "mreza", "stative", "pogodak", "golman", "gol", "kosarka", "fudbal", "odbojka", "rukomet", "lopta", "ledjni kraul", "prsno", "delfin", "kraul", "plivanje", "sport" };
            //Asocij = new List<string> { "lipidi", "vjestacko", "anabolički", "masa", "steroidi", "vaga", "dizanje", "kilogram", "težina", "teg", "trcanje", "bicikl", "vjezbanje", "snaga", "kondicija", "biceps", "triceps", "popaj", "srce", "mišići", "teretana" };
            return Asocij[ind];

        }

        private void A2_Click(object sender, RoutedEventArgs e)
        {
            A2.Content = asoc(1);
            A2.Background = Brushes.DeepSkyBlue;
        }

        private void A3_Click(object sender, RoutedEventArgs e)
        {
            A3.Content = asoc(2);
            A3.Background = Brushes.DeepSkyBlue;
        }

        private void A4_Click(object sender, RoutedEventArgs e)
        {
            A4.Content = asoc(3);
            A4.Background = Brushes.DeepSkyBlue;
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            B1.Content = asoc(5);
            B1.Background = Brushes.DeepSkyBlue;
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            B2.Content = asoc(6);
            B2.Background = Brushes.DeepSkyBlue;
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            B3.Content = asoc(7);
            B3.Background = Brushes.DeepSkyBlue;
        }

        private void B4_Click(object sender, RoutedEventArgs e)
        {
            B4.Content = asoc(8);
            B4.Background = Brushes.DeepSkyBlue;
        }

        private void C1_Click(object sender, RoutedEventArgs e)
        {
            C1.Content = asoc(10);
            C1.Background = Brushes.DeepSkyBlue;
        }

        private void C2_Click(object sender, RoutedEventArgs e)
        {
            C2.Content = asoc(11);
            C2.Background = Brushes.DeepSkyBlue;
        }

        private void C3_Click(object sender, RoutedEventArgs e)
        {
            C3.Content = asoc(12);
            C3.Background = Brushes.DeepSkyBlue;
        }

        private void C4_Click(object sender, RoutedEventArgs e)
        {
            C4.Content = asoc(13);
            C4.Background = Brushes.DeepSkyBlue;
        }

        private void D1_Click(object sender, RoutedEventArgs e)
        {
            D1.Content = asoc(15);
            D1.Background = Brushes.DeepSkyBlue;
        }

        private void D2_Click(object sender, RoutedEventArgs e)
        {
            D2.Content = asoc(16);
            D2.Background = Brushes.DeepSkyBlue;
        }

        private void D3_Click(object sender, RoutedEventArgs e)
        {
            D3.Content = asoc(17);
            D3.Background = Brushes.DeepSkyBlue;
        }

        private void D4_Click(object sender, RoutedEventArgs e)
        {
            D4.Content = asoc(18);
            D4.Background = Brushes.DeepSkyBlue;
        }

        private void A_Click(object sender, RoutedEventArgs e)
        {
            if (A.Content != asoc(4))
            {
                unospojma.Visibility = System.Windows.Visibility.Visible;
            }
        }

        private void unospojma_TouchEnter(object sender, TouchEventArgs e)
        {
            unospojma.Visibility = System.Windows.Visibility.Hidden;
        }

        private void unospojma_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (unospojma.Text == asoc(4))
                {
                    A.Content = asoc(4);
                    A.Background = Brushes.DeepSkyBlue;
                    if (A1.Content != asoc(0))
                    {
                        BrojBodova += 1;
                        A1.Content = asoc(0);
                        A1.Background = Brushes.DeepSkyBlue;
                    }

                    if (A2.Content != asoc(1))
                    {
                        BrojBodova += 1;
                        A2.Content = asoc(1);
                        A2.Background = Brushes.DeepSkyBlue;
                    }

                    if (A3.Content != asoc(2))
                    {
                        BrojBodova += 1;
                        A3.Content = asoc(2);
                        A3.Background = Brushes.DeepSkyBlue;
                    }

                    if (A4.Content != asoc(3))
                    {
                        BrojBodova += 1;
                        A4.Content = asoc(3);
                        A4.Background = Brushes.DeepSkyBlue;
                    }
                    BrojBodova += 1;
                }
                else
                    MessageBox.Show("Ne možemo da prihvatimo odgovor");

                unospojma.Visibility = System.Windows.Visibility.Hidden;
            }
        }

        private void unospojmab_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (unospojmab.Text == asoc(9))
                {
                    B.Content = asoc(9);
                    B.Background = Brushes.DeepSkyBlue;

                    if (B1.Content != asoc(5))
                    {
                        BrojBodova += 1;
                        B1.Content = asoc(5);
                        B1.Background = Brushes.DeepSkyBlue;
                    }

                    if (B2.Content != asoc(6))
                    {
                        BrojBodova += 1;
                        B2.Content = asoc(6);
                        B2.Background = Brushes.DeepSkyBlue;
                    }

                    if (B3.Content != asoc(7))
                    {
                        BrojBodova += 1;
                        B3.Content = asoc(7);
                        B3.Background = Brushes.DeepSkyBlue;
                    }

                    if (B4.Content != asoc(8))
                    {
                        BrojBodova += 1;
                        B4.Content = asoc(8);
                        B4.Background = Brushes.DeepSkyBlue;
                    }
                    BrojBodova += 1;
                }
                else
                    MessageBox.Show("Ne možemo da prihvatimo odgovor");


                unospojmab.Visibility = System.Windows.Visibility.Hidden;
            }
        }

        private void unospojmac_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (unospojmac.Text == asoc(14))
                {
                    C.Content = asoc(14);
                    C.Background = Brushes.DeepSkyBlue;

                    if (C1.Content != asoc(10))
                    {
                        BrojBodova += 1;
                        C1.Content = asoc(10);
                        C1.Background = Brushes.DeepSkyBlue;
                    }

                    if (C2.Content != asoc(11))
                    {
                        BrojBodova += 1;
                        C2.Content = asoc(11);
                        C2.Background = Brushes.DeepSkyBlue;
                    }

                    if (C3.Content != asoc(12))
                    {
                        BrojBodova += 1;
                        C3.Content = asoc(12);
                        C3.Background = Brushes.DeepSkyBlue;
                    }

                    if (C4.Content != asoc(13))
                    {
                        BrojBodova += 1;
                        C4.Content = asoc(13);
                        C4.Background = Brushes.DeepSkyBlue;
                    }
                    BrojBodova += 1;
                }
                else
                    MessageBox.Show("Ne možemo da prihvatimo odgovor");

                unospojmac.Visibility = System.Windows.Visibility.Hidden;
            }
        }

        private void unospojmad_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (unospojmad.Text == asoc(19))
                {
                    D.Content = asoc(19);
                    D.Background = Brushes.DeepSkyBlue;
                    if (D1.Content != asoc(15))
                    {
                        BrojBodova += 1;
                        D1.Content = asoc(15);
                        D1.Background = Brushes.DeepSkyBlue;
                    }

                    if (D2.Content != asoc(16))
                    {
                        BrojBodova += 1;
                        D2.Content = asoc(16);
                        D2.Background = Brushes.DeepSkyBlue;
                    }

                    if (D3.Content != asoc(17))
                    {
                        BrojBodova += 1;
                        D3.Content = asoc(17);
                        D3.Background = Brushes.DeepSkyBlue;
                    }

                    if (D4.Content != asoc(18))
                    {
                        BrojBodova += 1;
                        D4.Content = asoc(18);
                        D4.Background = Brushes.DeepSkyBlue;
                    }
                    BrojBodova += 1;
                }
                else
                    MessageBox.Show("Ne možemo da prihvatimo odgovor");
                unospojmad.Visibility = System.Windows.Visibility.Hidden;
            }
        }

        private void B_Click(object sender, RoutedEventArgs e)
        {
            if (B.Content != asoc(9))
                unospojmab.Visibility = System.Windows.Visibility.Visible;
        }

        private void C_Click(object sender, RoutedEventArgs e)
        {
            if (C.Content != asoc(14))
                unospojmac.Visibility = System.Windows.Visibility.Visible;
        }

        private void D_Click(object sender, RoutedEventArgs e)
        {
            if (D.Content != asoc(19))
                unospojmad.Visibility = System.Windows.Visibility.Visible;
        }

        private void konacno_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (konacno.Text == asoc(20))
                {
                    rezultat.Content = asoc(20);
                    rezultat.Background = Brushes.DeepSkyBlue;
                    if (A1.Content != asoc(0))
                    {
                        BrojBodova += 1;
                        A1.Content = asoc(0);
                        A1.Background = Brushes.DeepSkyBlue;
                    }

                    if (A2.Content != asoc(1))
                    {
                        BrojBodova += 1;
                        A2.Content = asoc(1);
                        A2.Background = Brushes.DeepSkyBlue;
                    }

                    if (A3.Content != asoc(2))
                    {
                        BrojBodova += 1;
                        A3.Content = asoc(2);
                        A3.Background = Brushes.DeepSkyBlue;
                    }

                    if (A4.Content != asoc(3))
                    {
                        BrojBodova += 1;
                        A4.Content = asoc(3);
                        A4.Background = Brushes.DeepSkyBlue;
                    }
                    if (A.Content != asoc(4))
                    {
                        BrojBodova += 10;
                        A.Content = asoc(4);
                        A.Background = Brushes.DeepSkyBlue;
                    }

                    if (B1.Content != asoc(5))
                    {
                        BrojBodova += 1;
                        B1.Content = asoc(5);
                        B1.Background = Brushes.DeepSkyBlue;
                    }

                    if (B2.Content != asoc(6))
                    {
                        BrojBodova += 1;
                        B2.Content = asoc(6);
                        B2.Background = Brushes.DeepSkyBlue;
                    }

                    if (B3.Content != asoc(7))
                    {
                        BrojBodova += 1;
                        B3.Content = asoc(7);
                        B3.Background = Brushes.DeepSkyBlue;
                    }

                    if (B4.Content != asoc(8))
                    {
                        BrojBodova += 1;
                        B4.Content = asoc(8);
                        B4.Background = Brushes.DeepSkyBlue;
                    }
                    if (B.Content != asoc(9))
                    {
                        BrojBodova += 10;
                        B.Content = asoc(9);
                        B.Background = Brushes.DeepSkyBlue;
                    }
                    if (C1.Content != asoc(10))
                    {
                        BrojBodova += 1;
                        C1.Content = asoc(10);
                        C1.Background = Brushes.DeepSkyBlue;
                    }

                    if (C2.Content != asoc(11))
                    {
                        BrojBodova += 1;
                        C2.Content = asoc(11);
                        C2.Background = Brushes.DeepSkyBlue;
                    }

                    if (C3.Content != asoc(12))
                    {
                        BrojBodova += 1;
                        C3.Content = asoc(12);
                        C3.Background = Brushes.DeepSkyBlue;
                    }

                    if (C4.Content != asoc(13))
                    {
                        BrojBodova += 1;
                        C4.Content = asoc(13);
                        C4.Background = Brushes.DeepSkyBlue;
                    }

                    if (C.Content != asoc(14))
                    {
                        BrojBodova += 10;
                        C.Content = asoc(14);
                        C.Background = Brushes.DeepSkyBlue;
                    }

                    if (D1.Content != asoc(15))
                    {
                        BrojBodova += 1;
                        D1.Content = asoc(15);
                        D1.Background = Brushes.DeepSkyBlue;
                    }

                    if (D2.Content != asoc(16))
                    {
                        BrojBodova += 1;
                        D2.Content = asoc(16);
                        D2.Background = Brushes.DeepSkyBlue;
                    }

                    if (D3.Content != asoc(17))
                    {
                        BrojBodova += 1;
                        D3.Content = asoc(17);
                        D3.Background = Brushes.DeepSkyBlue;
                    }

                    if (D4.Content != asoc(18))
                    {
                        BrojBodova += 1;
                        D4.Content = asoc(18);
                        D4.Background = Brushes.DeepSkyBlue;
                    }

                    if (D.Content != asoc(19))
                    {
                        BrojBodova += 10;
                        D.Content = asoc(19);
                        D.Background = Brushes.DeepSkyBlue;
                    }

                    MessageBox.Show("Ukupa broj bodova: " + Convert.ToSingle(BrojBodova));
                    SlikeR igra = new SlikeR();
                    igra.Show();
                    this.Close();
                }
                else
                    MessageBox.Show("Ne možemo da prihvatimo odgovor");
                konacno.Visibility = System.Windows.Visibility.Hidden;
            }
        }

        private void rezultat_Click(object sender, RoutedEventArgs e)
        {
            if (rezultat.Content != asoc(20))
            {
                konacno.Visibility = System.Windows.Visibility.Visible;
            }
        }

        private void hint1_Click(object sender, RoutedEventArgs e)
        {
            hintA.Visibility = Visibility.Visible;
        }

        private void hint2_Click(object sender, RoutedEventArgs e)
        {
            hintB.Visibility = Visibility.Visible;
        }

        private void hint3_Click(object sender, RoutedEventArgs e)
        {
            hintC.Visibility = Visibility.Visible;
        }

        private void hint4_Click(object sender, RoutedEventArgs e)
        {
            hintD.Visibility = Visibility.Visible;
        }

        private void hint5_Click(object sender, RoutedEventArgs e)
        {
            hintK.Visibility = Visibility.Visible;
        }

        private void predaja_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ukupna broj bodova: " + Convert.ToSingle(BrojBodova));
            SlikeR igra = new SlikeR();
            igra.Show();
            this.Close();
        }

    }
}
