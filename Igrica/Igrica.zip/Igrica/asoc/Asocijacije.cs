﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace asoc
{
    class Asocijacije
    {
        public class asocijacija
        {
            public static void initAcos(int koji)
            {
                if (koji == 1)
                {
                    dodaj("7 clanova");
                    dodaj("igraci");
                    dodaj("vodeni sport");
                    dodaj("lopta");
                    dodaj("vaterpolo");
                    dodaj("mreza");
                    dodaj("stative");
                    dodaj("pogodak");
                    dodaj("golman");
                    dodaj("gol");
                    dodaj("kosarka");
                    dodaj("fudbal");
                    dodaj("odbojka");
                    dodaj("rukomet");
                    dodaj("lopta");
                    dodaj("ledjni kraul");
                    dodaj("prsno");
                    dodaj("delfin");
                    dodaj("kraul");
                    dodaj("plivanje");
                    dodaj("sport");
                }
                if (koji == 2)
                {
                    dodaj("lipidi");
                    dodaj("vjestacko");
                    dodaj("anabolički");
                    dodaj("masa");
                    dodaj("steroidi"); //a
                    dodaj("vaga");
                    dodaj("dizanje");
                    dodaj("kilogram");
                    dodaj("težina");
                    dodaj("teg"); //b
                    dodaj("trcanje");
                    dodaj("bicikl");
                    dodaj("vjezbanje");
                    dodaj("snaga");
                    dodaj("kondicija"); //c
                    dodaj("biceps");
                    dodaj("triceps");
                    dodaj("popaj");
                    dodaj("srce");
                    dodaj("mišići");//d
                    dodaj("teretana"); //konacno
                }
            }
            private static void dodaj(string s)
            {
                ListaA i = null;
                i = new ListaA();
                i.Naziv = s;
                Asocijacija.asoc.Add(i);
            }

            public static string AsocVri(int koji)
            {
                return Asocijacija.asoc.ElementAt(koji).Naziv;
            }

            public static string KonacnoAsoc()
            {
                return Asocijacija.asoc.ElementAt(20).Naziv;
            }

        }


    }
}
