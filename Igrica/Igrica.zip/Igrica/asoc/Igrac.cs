﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asoc
{
    class Igrac
    {
        private int _score;
        private String _username;
        private int _level;
        private static Igrac _igrac = new Igrac();

        private  Igrac () { }

        public Igrac Igracc
        {
            get 
            { 
                return _igrac;
            }
        }
        
        public int Level
        {
            get { return _level; }
            set { _level = value; }
        }
        

        public String Username
        {
            get { return _username; }
            set { _username = value; }
        }
        
        public int Score
        {
            get { return _score; }
            set { _score = value; }
        }

        public void obracunajLevel()
        { }

        public static Igrac KreirajIgraca()
        {
            if (_igrac == null)
            {
                _igrac = new Igrac();
            }
            return _igrac;
        }
    }
}
