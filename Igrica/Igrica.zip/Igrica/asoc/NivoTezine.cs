﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asoc
{
    class NivoTezine
    {
        //1 za tesko, 0 za lagano
        private bool _tesko;

        public bool Tesko
        {
            get { return _tesko; }
            set { _tesko = value; }
        }
        
    }
}
