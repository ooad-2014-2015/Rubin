﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace asoc
{
    /// <summary>
    /// Interaction logic for SlikeR.xaml
    /// </summary>
    public partial class SlikeR : Window
    {
        public static bool Expert;
        int BrojBodova = 0;
        public SlikeR()
        {
            InitializeComponent();
            if (!Expert) hintS.Visibility = System.Windows.Visibility.Visible;
        }

        private void A3_Click(object sender, RoutedEventArgs e)
        {
            S1.Visibility = Visibility.Hidden;
            S1.Background = Brushes.DeepSkyBlue;
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            S2.Visibility = Visibility.Hidden;
            S2.Background = Brushes.DeepSkyBlue;
        }

        private void D3_Click(object sender, RoutedEventArgs e)
        {
            S3.Visibility = Visibility.Hidden;
            S3.Background = Brushes.DeepSkyBlue;
        }

        private void D4_Click(object sender, RoutedEventArgs e)
        {
            S4.Visibility = Visibility.Hidden;
            S4.Background = Brushes.DeepSkyBlue;
        }

        private void hint2_Click(object sender, RoutedEventArgs e)
        {
            hintS1.Visibility = Visibility.Visible;
        }

        private void TextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (konacnoslika.Text == "bazen")
                {
                    BrojBodova += 5;
                    MessageBox.Show("Ukupan broj bodova je: " + Convert.ToSingle(BrojBodova));
                }
                else
                    MessageBox.Show("Ne možemo da prihvatimo odgovor");
            }
            
        }

        private void konacnoslika_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

    }
}
