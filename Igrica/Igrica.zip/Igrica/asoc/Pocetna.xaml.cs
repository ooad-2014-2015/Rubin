﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace asoc
{
    /// <summary>
    /// Interaction logic for Pocetna.xaml
    /// </summary>
    public partial class Pocetna : Window
    {
        public Pocetna()
        {
            InitializeComponent();
            MainWindow.Expert = true;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(!(string.IsNullOrEmpty(t_username.Text)))
            {
                Igrac ig = Igrac.KreirajIgraca();
                ig.Username = t_username.Text;
                MainWindow asocijacije = new MainWindow();
                asocijacije.Show();
                this.Close();
            }
            
            else MessageBox.Show("Morate unijeti username!");
        }

        private void expert_Checked(object sender, RoutedEventArgs e)
        {
            MainWindow.Expert = (expert.IsChecked==true);
        }

        private void beginner_Checked(object sender, RoutedEventArgs e)
        {
            MainWindow.Expert = !(beginner.IsChecked == true);
        }
    }
}
